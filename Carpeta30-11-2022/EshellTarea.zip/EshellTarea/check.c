#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main ()
{
	if (system("/usr/binds/ls")==0) {
    	printf("Existe\n");
} else {
    	printf("Fallo\n");
}
	return 0;
}
