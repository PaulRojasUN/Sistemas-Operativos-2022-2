#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define printf_vector(v,n) for (int i = 0; i < n; i++) { printf("%d",v[i]); } printf("\n")


int main(int argc, char * argv[])
{
	// Keep printing tokens while one of the
	// delimiters present in str[].
if (argc > 1){
	char * token = strtok(getenv("PATH"), ":");
	char auxA[argc-1][100];
	for (int i =0; i < argc-1; i++)
	{
		strcpy(auxA[i],argv[i+1]);
	}
	printf("Este es %s\n", auxA[0]);
	printf("Este es otro %s\n", argv[1]);
	for (int i = 0; i<argc-1; i++)
                {
                        printf("%s\n", auxA[i]);
                }
		/*
		printf("#################\n");
		printf(" THe token: %s\n", token);
                strcpy(auxA[0], token);
		printf("1: %s\n", auxA[0]);
	        strcat(auxA[0],"/");
		printf("2: %s\n", auxA[0]);
                strcat(auxA[0], argv[1]);
		printf("3: %s\n", auxA[0]);
		for (int i = 0; i<argc-1; i++)
                {
                        printf("%s ", auxA[i]);
                }
		*/
	
	while (token != NULL)
        {
		strcpy(auxA[0], token);
        	strcat(auxA[0],"/");
        	strcat(auxA[0], argv[1]);
                token = strtok(NULL, ":");
		for (int i = 0; i<argc-1; i++)
        	{
                	printf("%s ", auxA[i]);
        	}
		printf("\n");
	}
	printf("\n");
}
	return 0;
}
